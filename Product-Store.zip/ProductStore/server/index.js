import express from 'express';
import dotenv from 'dotenv';
import { connectDB } from './config/database.js';
import productroutes from './routes/productroute.js';
import path from 'path';
import cors from 'cors';
import exp from 'constants';

dotenv.config(); 
const app = express();
app.use(cors())
//Processes the port
const PORT = process.env.PORT || 3000;

app.use(express.json()) 

const __dirname = path.resolve;

app.use('/api/products', productroutes); // = app.use('/api/product/')

if(process.env.NODE_ENV === "production") {
    app.use(express.static(path.join(__dirname, '/ui/dist')));

    app.get('*', (req, res) => {
        res.sendFile(path.resolve(__dirname, 'ui', 'dist', 'index.html'));
    })
}

app.listen(PORT, () => {
    connectDB();
    console.log(`Server running at http://localhost:${PORT}`);
});

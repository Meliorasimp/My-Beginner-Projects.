import { useState } from 'react'; 
import { Button, Container, Heading, Input, VStack, useToast } from '@chakra-ui/react';
import { useProductStore } from '../store/product';

const Createpage = () => {
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    image: '',
  });

  const toast = useToast();
  const { createProduct } = useProductStore();

  const handleAddProduct = async () => {
    const { success, message } = await createProduct(newProduct);
    if (!success) {
      toast({
        title: 'Error',
        description: message,
        status: 'error',
        isClosable: true,
      });
    } else {
      toast({
        title: 'Success',
        description: message,
        status: 'success',
        isClosable: true,
      });
    }

    setNewProduct({name: '', price: '', image:''})
  };

  return (
    <Container maxW={'container.sm'}>
      <Heading as={'h1'} textAlign={'center'} mb={4}>Create New Product</Heading>
      <VStack spacing={8}>
        <Input 
          placeholder='Product Name'
          value={newProduct.name}
          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
        />
        <Input 
          placeholder='Price'
          value={newProduct.price}
          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
        />
        <Input 
          placeholder='Image URL'
          value={newProduct.image}
          onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
        />
        <Button onClick={handleAddProduct}>Add Product</Button>
      </VStack>
    </Container>
  );
};

export default Createpage;

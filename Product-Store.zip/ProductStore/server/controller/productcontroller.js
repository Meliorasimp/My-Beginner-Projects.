import Productmodel from "../models/productmodel.js";
import mongoose from "mongoose";
const { ObjectId } = mongoose.Types;

export const getProduct = async (req, res) => {
    try{
        const products = await Productmodel.find({});
        res.status(200).json({success: true, data: products})
    } catch (error) {
        console.log("error in fetching products:", error.message);
        res.status(500).json({success:false, message:"Cannot find data of products"});
    }
}   

export const postProduct = async (req, res) => {
    const products = req.body; //User will send the data or Body will make a Request to the user
    if (!products.name || !products.price || !products.image) {
        return res.status(400).json({ success: false, message: "Please provide all fields" });
    }
    //Create a new Instance of the Productmodel to prepare to save the data to the database. (Required to do this step!!)
    const newProduct = new Productmodel(products);
    try {
        //Save the data to the Database
        await newProduct.save();
        res.status(201).json({ success: true, data: newProduct });
    } catch (error) {
        console.error("Error in Create Product:", error.message);
        res.status(500).json({ success: false, message: "Server error" });
    }
}

export const deleteProduct = async (req, res) => {
  const { id } = req.params;
  try {
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: "Invalid product ID" });
    }
    const deletedProduct = await Productmodel.findByIdAndDelete(new ObjectId(id)); // Use 'new' to create an ObjectId
    if (!deletedProduct) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    res.status(200).json({ success: true, message: "Product deleted!" });
  } catch (error) {
    console.error("Error in Delete Product:", error.message);
    res.status(500).json({ success: false, message: `Server error: ${error.message}` });
  }
};

export const updateProduct = async (req, res) => {
    const { id } = req.params;
    const products = req.body;

    console.log(`Request ID: ${id}`);
    console.log(`Request Body: ${JSON.stringify(products)}`);

    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(404).json({ success: false, message: "Invalid Product ID" });
    }

    try {
        const updatedProduct = await Productmodel.findByIdAndUpdate(id, products, { new: true });
        console.log(`Updated Product: ${JSON.stringify(updatedProduct)}`);
        if (!updatedProduct) {
            return res.status(404).json({ success: false, message: "Product not found" });
        }
        res.status(200).json({ success: true, data: updatedProduct });
    } catch (error) {
        console.error("Error in Update Product:", error.message);
        res.status(500).json({ success: false, message: "Server error" });
    }
}